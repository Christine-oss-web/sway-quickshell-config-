import Quickshell
import Quickshell.Wayland
import Quickshell.Io
import QtQuick
import QtQuick.Layouts

ShellRoot {
    id: root

    // Rosé Pine Moon Palette
    property color colPillBg: "#2a273f"   // Surface
    property color colFg: "#e0def4"       // Text
    property color colMuted: "#393552"    // Border
    property color colSubtle: "#6e6a86"   // Muted Text
    property color colCyan: "#9ccfd8"     // Foam
    property color colPurple: "#c4a7e7"   // Iris
    property color colRed: "#eb6f92"      // Love
    property color colYellow: "#f6c177"   // Gold
    property color colRose: "#ea9a97"     // Rose

    // Font
    property string fontFamily: "IosevkaTerm Nerd Font"
    property int fontSize: 12

    // System info properties
    property int volumeLevel: 0
    property string mediaTitle: "No Media"
    property bool isPlaying: false
    property string activeWindow: "Desktop"
    property string currentLayout: "Tiled"
    property int focusedWorkspace: 1
    property var occupiedWorkspaces: []

    // Live Audio Sink Fetcher
    Process {
        id: volProc
        command: ["wpctl", "get-volume", "@DEFAULT_AUDIO_SINK@"]
        running: false
        stdout: SplitParser {
            onRead: data => {
                if (!data) return
                var match = data.match(/Volume:\s*([\d.]+)/)
                if (match) {
                    volumeLevel = Math.round(parseFloat(match[1]) * 100)
                }
            }
        }
    }

    // Real-time Audio Listener
    Process {
        id: volSubProc
        command: ["sh", "-c", "pactl subscribe | grep --line-buffered 'sink'"]
        running: true
        stdout: SplitParser {
            onRead: data => {
                volProc.running = false
                volProc.running = true
            }
        }
    }

    // Media Player Tracker (playerctl)
    Process {
        id: mediaProc
        command: ["playerctl", "metadata", "--format", "{{status}}|{{title}} - {{artist}}", "--follow"]
        running: true
        stdout: SplitParser {
            onRead: data => {
                if (!data) return
                var parts = data.trim().split('|')
                if (parts.length >= 2) {
                    isPlaying = (parts[0] === "Playing")
                    var title = parts[1].trim()
                    mediaTitle = (title !== "" && title !== "-") ? title : "No Media"
                }
            }
        }
    }

    // Active window title (sway)
    Process {
        id: windowProc
        command: ["sh", "-c", "swaymsg -t get_tree | jq -r '.. | select(.focused? == true) | .name // empty' | head -1"]
        running: false
        stdout: SplitParser {
            onRead: data => {
                if (data && data.trim()) {
                    activeWindow = data.trim()
                }
            }
        }
    }

    // Current layout (sway)
    Process {
        id: layoutProc
        command: ["sh", "-c", "swaymsg -t get_tree | jq -r '.. | select(.focused? == true) | .layout // empty' | head -1"]
        running: false
        stdout: SplitParser {
            onRead: data => {
                if (data && data.trim()) {
                    var layout = data.trim()
                    if (layout === "splith") {
                        currentLayout = "Horizontal"
                    } else if (layout === "splitv") {
                        currentLayout = "Vertical"
                    } else if (layout === "tabbed") {
                        currentLayout = "Tabbed"
                    } else if (layout === "stacking") {
                        currentLayout = "Stacking"
                    } else if (layout === "output" || layout === "none") {
                        currentLayout = "Tiled"
                    } else {
                        currentLayout = layout.charAt(0).toUpperCase() + layout.slice(1)
                    }
                }
            }
        }
    }

    // Focused workspace (sway)
    Process {
        id: workspaceProc
        command: ["sh", "-c", "swaymsg -t get_workspaces | jq -r '.[] | select(.focused == true) | .num'"]
        running: false
        stdout: SplitParser {
            onRead: data => {
                if (data && data.trim()) {
                    var num = parseInt(data.trim())
                    if (!isNaN(num)) focusedWorkspace = num
                }
            }
        }
    }

    // Occupied workspaces (sway)
    Process {
        id: occupiedProc
        command: ["sh", "-c", "swaymsg -t get_workspaces | jq -r '.[].num'"]
        running: false
        stdout: SplitParser {
            onRead: data => {
                if (data && data.trim()) {
                    var nums = data.trim().split('\n').map(n => parseInt(n)).filter(n => !isNaN(n))
                    occupiedWorkspaces = nums
                }
            }
        }
    }

    // Polling Timers
    Timer {
        interval: 2000
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: {
            volProc.running = false; volProc.running = true
        }
    }

    Timer {
        interval: 200
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: {
            windowProc.running = false; windowProc.running = true
            layoutProc.running = false; layoutProc.running = true
            workspaceProc.running = false; workspaceProc.running = true
            occupiedProc.running = false; occupiedProc.running = true
        }
    }

    Variants {
        model: Quickshell.screens

        PanelWindow {
            property var modelData
            screen: modelData

            anchors {
                top: true
                left: true
                right: true
            }

            implicitHeight: 34
            color: "transparent"

            RowLayout {
                anchors.fill: parent
                anchors.leftMargin: 8
                anchors.rightMargin: 8
                anchors.topMargin: 4
                anchors.bottomMargin: 4
                spacing: 6

                // 1. NixOS Logo Block
                Rectangle {
                    Layout.preferredWidth: 30
                    Layout.preferredHeight: 26
                    color: root.colPillBg
                    border.color: root.colMuted
                    border.width: 1

                    Image {
                        anchors.centerIn: parent
                        width: 18
                        height: 18
                        source: "file:///home/$USER/.config/quickshell/icons/tonybtw.png"
                        fillMode: Image.PreserveAspectFit
                    }
                }

                // 2. Workspaces Block
                Rectangle {
                    Layout.preferredWidth: wsRow.implicitWidth + 12
                    Layout.preferredHeight: 26
                    color: root.colPillBg
                    border.color: root.colMuted
                    border.width: 1

                    Row {
                        id: wsRow
                        anchors.centerIn: parent
                        spacing: 2

                        Repeater {
                            model: 6

                            Rectangle {
                                width: 20
                                height: 20
                                color: "transparent"

                                property bool isActive: focusedWorkspace === (index + 1)
                                property bool hasWindows: occupiedWorkspaces.indexOf(index + 1) !== -1

                                Text {
                                    text: index + 1
                                    color: parent.isActive ? root.colRose : (parent.hasWindows ? root.colCyan : root.colSubtle)
                                    font.pixelSize: root.fontSize
                                    font.family: root.fontFamily
                                    font.bold: true
                                    anchors.centerIn: parent
                                }

                                MouseArea {
                                    anchors.fill: parent
                                    onClicked: {
                                        var proc = Qt.createQmlObject('import Quickshell.Io; Process { }', parent)
                                        proc.command = ["swaymsg", "workspace", String(index + 1)]
                                        proc.running = true
                                    }
                                }
                            }
                        }
                    }
                }

                // 3. Layout Mode Block
                Rectangle {
                    Layout.preferredWidth: modeText.implicitWidth + 16
                    Layout.preferredHeight: 26
                    color: root.colPillBg
                    border.color: root.colMuted
                    border.width: 1

                    Text {
                        id: modeText
                        anchors.centerIn: parent
                        text: currentLayout
                        color: root.colFg
                        font.pixelSize: root.fontSize
                        font.family: root.fontFamily
                        font.bold: true
                    }
                }

                // 4. Window Name Block
                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 26
                    color: root.colPillBg
                    border.color: root.colMuted
                    border.width: 1

                    Text {
                        anchors.fill: parent
                        anchors.leftMargin: 10
                        anchors.rightMargin: 10
                        verticalAlignment: Text.AlignVCenter
                        text: activeWindow
                        color: root.colPurple
                        font.pixelSize: root.fontSize
                        font.family: root.fontFamily
                        font.bold: true
                        elide: Text.ElideRight
                        maximumLineCount: 1
                    }
                }

                // 5. Media Player Block
                Rectangle {
                    Layout.preferredWidth: mediaRow.implicitWidth + 16
                    Layout.preferredHeight: 26
                    color: root.colPillBg
                    border.color: root.colMuted
                    border.width: 1

                    RowLayout {
                        id: mediaRow
                        anchors.centerIn: parent
                        spacing: 6

                        Text {
                            text: isPlaying ? "󰏤" : "󰐊"
                            color: root.colYellow
                            font.pixelSize: root.fontSize
                            font.family: root.fontFamily
                        }

                        Text {
                            text: mediaTitle
                            color: root.colYellow
                            font.pixelSize: root.fontSize
                            font.family: root.fontFamily
                            font.bold: true
                            elide: Text.ElideRight
                            Layout.maximumWidth: 160
                        }
                    }

                    MouseArea {
                        anchors.fill: parent
                        cursorShape: Qt.PointingHandCursor
                        onClicked: {
                            var proc = Qt.createQmlObject('import Quickshell.Io; Process { }', parent)
                            proc.command = ["playerctl", "play-pause"]
                            proc.running = true
                        }
                        onWheel: wheel => {
                            var proc = Qt.createQmlObject('import Quickshell.Io; Process { }', parent)
                            proc.command = ["playerctl", wheel.angleDelta.y > 0 ? "next" : "previous"]
                            proc.running = true
                        }
                    }
                }

                // 6. Volume Block
                Rectangle {
                    Layout.preferredWidth: volText.implicitWidth + 16
                    Layout.preferredHeight: 26
                    color: root.colPillBg
                    border.color: root.colMuted
                    border.width: 1

                    Text {
                        id: volText
                        anchors.centerIn: parent
                        text: "󰕾 " + volumeLevel + "%"
                        color: root.colRose
                        font.pixelSize: root.fontSize
                        font.family: root.fontFamily
                        font.bold: true
                    }

                    MouseArea {
                        anchors.fill: parent
                        cursorShape: Qt.PointingHandCursor
                        onClicked: {
                            var proc = Qt.createQmlObject('import Quickshell.Io; Process { }', parent)
                            proc.command = ["sh", "-c", "swaymsg exec 'foot -e pulsemixer || alacritty -e pulsemixer || kitty -e pulsemixer'"]
                            proc.running = true
                        }
                        onWheel: wheel => {
                            var proc = Qt.createQmlObject('import Quickshell.Io; Process { }', parent)
                            proc.command = ["wpctl", "set-volume", "@DEFAULT_AUDIO_SINK@", wheel.angleDelta.y > 0 ? "5%+" : "5%-"]
                            proc.running = true
                        }
                    }
                }

                // 7. Date and Time Block
                Rectangle {
                    Layout.preferredWidth: clockText.implicitWidth + 16
                    Layout.preferredHeight: 26
                    color: root.colPillBg
                    border.color: root.colMuted
                    border.width: 1

                    Text {
                        id: clockText
                        anchors.centerIn: parent
                        text: Qt.formatDateTime(new Date(), "ddd, MMM dd - HH:mm")
                        color: root.colCyan
                        font.pixelSize: root.fontSize
                        font.family: root.fontFamily
                        font.bold: true

                        Timer {
                            interval: 1000
                            running: true
                            repeat: true
                            onTriggered: clockText.text = Qt.formatDateTime(new Date(), "ddd, MMM dd - HH:mm")
                        }
                    }
                }
            }
        }
    }
  }
